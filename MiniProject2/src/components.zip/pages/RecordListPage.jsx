import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

function RecordListPage() {
  const [records, setRecords] = useState([]);

  useEffect(() => {
    fetchRecords();  // 컴포넌트가 마운트되면 기록 목록을 가져옴
  }, []);

  const fetchRecords = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/records");
      const data = await response.json();
      setRecords(data);
    } catch (error) {
      console.error("기록을 불러오는 중 오류가 발생했습니다:", error);
    }
  };

  if (records.length === 0) {
    return <p>기록이 없습니다.</p>;
  }

  return (
    <div>
      <h2>기록 목록</h2>
      <ul>
        {records.map((record) => (
          <li key={record.id}>
            <Link to={`/record/${record.id}`}>
              {record.runningDate} - {record.spot}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecordListPage;